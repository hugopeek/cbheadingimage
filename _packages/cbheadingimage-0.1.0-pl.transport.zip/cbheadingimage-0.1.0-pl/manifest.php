<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '18ff5e8d9686105b0bf4187c714e9c85',
      'native_key' => 'cbheadingimage',
      'filename' => 'modNamespace/015bb9589c9765fca2e61935b872622d.vehicle',
      'namespace' => 'cbheadingimage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'dd141f935acdefa0e6ea50d1c3d0ffdc',
      'native_key' => NULL,
      'filename' => 'modCategory/96a41d5df0420f171d4d5b7384039324.vehicle',
      'namespace' => 'cbheadingimage',
    ),
  ),
);