<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '087f73868b9e95678f314bbc2beaf032',
      'native_key' => 'cbheadingimage',
      'filename' => 'modNamespace/51e76c28fc46f9d8a001068606a1b701.vehicle',
      'namespace' => 'cbheadingimage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6d744880480d13b86bcbfa094d7c0f50',
      'native_key' => NULL,
      'filename' => 'modCategory/410b50dd423d98144adf7aa8f9926881.vehicle',
      'namespace' => 'cbheadingimage',
    ),
  ),
);