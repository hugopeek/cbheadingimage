<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e398083276061d1cf2333591ebe36362',
      'native_key' => 'cbheadingimage',
      'filename' => 'modNamespace/ac830f4bc4248f9e398bb28c939f88a7.vehicle',
      'namespace' => 'cbheadingimage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9132994d03a57d86fc73f51ee3d7e22a',
      'native_key' => NULL,
      'filename' => 'modCategory/c4cd06615ad06856b5c273e82a589c72.vehicle',
      'namespace' => 'cbheadingimage',
    ),
  ),
);